setwd("C:\\Users\\IT24103533\\Desktop\\LAB8")

##Q1
weights <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)

pop_mean <- mean(weights$Weight.kg.)
pop_sd <- sd(weights$Weight.kg.)

cat("Population Mean:", pop_mean, "kg\n")
cat("Population Standard Deviation:", pop_sd, "kg\n")

##Q2
set.seed(42)
sample_means <- c()
sample_sds <- c()

for (i in 1:25) {
  sample <- sample(weights$Weight.kg., size = 6, replace = TRUE)
  sample_mean <- mean(sample)
  sample_sd <- sd(sample)
  
  sample_means <- c(sample_means, sample_mean)
  sample_sds <- c(sample_sds, sample_sd)
  
  cat(sprintf("Sample %02d: Mean = %.3f, SD = %.3f\n", i, sample_mean, sample_sd))
}

##Q3
weights <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)

set.seed(42)

sample_means <- c()
sample_sds <- c()

for (i in 1:25) {
  sample <- sample(weights$Weight.kg., size = 6, replace = TRUE)
  sample_means <- c(sample_means, mean(sample))
  sample_sds <- c(sample_sds, sd(sample))
}


mean_sample_means <- mean(sample_means)
sd_sample_means <- sd(sample_means)

pop_mean <- mean(weights$Weight.kg.)
pop_sd <- sd(weights$Weight.kg.)

cat("Mean of Sample Means:", mean_sample_means, "kg\n")
cat("Standard Deviation of Sample Means:", sd_sample_means, "kg\n")
cat("Population Mean:", pop_mean, "kg\n")
cat("Population Standard Deviation:", pop_sd, "kg\n")

cat("Interpretation:\n")
cat("The mean of the sample means is close to the population mean.\n")
cat("The standard deviation of the sample means is smaller than the population standard deviation,\n")
cat("which is expected due to the Central Limit Theorem.\n")







