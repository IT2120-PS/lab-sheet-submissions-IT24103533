setwd("C:\\Users\\dilanka\\Desktop\\IT24103533")
#Q1 
n <- 50        
p <- 0.85
#(i)
# X ~ Binomial(n=50, p=0.85)

# probability for at least 47 students passed the test
prob_47_or_more <- sum(dbinom(47:50, size = n, prob = p))
prob_47_or_more


#Q2
lambda <- 12   
#(i)
# X = number of customer calls per hour

#(ii) 
# X Poisson(lambda = 12)

#(iii) 
prob_15_calls <- dpois(15, lambda = lambda)
prob_15_calls

